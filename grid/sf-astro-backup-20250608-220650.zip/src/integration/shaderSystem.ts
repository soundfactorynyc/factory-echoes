/**
 * GRID OS: Shader System
 * 
 * This module provides a shader system for the GRID OS Integration Core,
 * allowing for the management of WebGL shaders and materials.
 */

import type { WebGLShader, MaterialConfig } from '../types/webgl';

/**
 * Shader system for the GRID OS Integration Core
 */
export class ShaderSystem {
  /**
   * Active shaders
   */
  public readonly activeShaders: Map<string, WebGLShader> = new Map();
  
  /**
   * Material presets
   */
  public readonly materialPresets: {
    /**
     * Carbon fiber material
     */
    carbonFiber: MaterialConfig;
    
    /**
     * Gold accent material
     */
    goldAccent: MaterialConfig;
    
    /**
     * Cyan glow material
     */
    cyanGlow: MaterialConfig;
    
    /**
     * Studio metal material
     */
    studioMetal: MaterialConfig;
  };
  
  /**
   * Post-processing effects
   */
  public readonly postProcessing: {
    /**
     * Bloom effect
     */
    bloom: boolean;
    
    /**
     * Motion blur effect
     */
    motionBlur: boolean;
    
    /**
     * Chromatic aberration effect
     */
    chromaticAberration: boolean;
    
    /**
     * Film grain effect
     */
    filmGrain: boolean;
  };
  
  /**
   * Create a new shader system
   */
  constructor() {
    // Initialize material presets
    this.materialPresets = {
      carbonFiber: {
        name: 'Carbon Fiber',
        type: 'pbr',
        properties: {
          baseColor: [0.05, 0.05, 0.05, 1.0],
          metallic: 0.0,
          roughness: 0.3,
          normalScale: 1.0,
          emissive: [0.0, 0.0, 0.0],
          specular: 0.5,
          textures: {
            albedo: 'textures/carbon_fiber_albedo.png',
            normal: 'textures/carbon_fiber_normal.png',
            roughness: 'textures/carbon_fiber_roughness.png',
            ao: 'textures/carbon_fiber_ao.png'
          }
        }
      },
      goldAccent: {
        name: 'Gold Accent',
        type: 'pbr',
        properties: {
          baseColor: [1.0, 0.8, 0.0, 1.0],
          metallic: 1.0,
          roughness: 0.1,
          normalScale: 0.5,
          emissive: [0.2, 0.1, 0.0],
          specular: 1.0,
          textures: {
            albedo: 'textures/gold_albedo.png',
            normal: 'textures/gold_normal.png',
            metallic: 'textures/gold_metallic.png',
            roughness: 'textures/gold_roughness.png'
          }
        }
      },
      cyanGlow: {
        name: 'Cyan Glow',
        type: 'emissive',
        properties: {
          baseColor: [0.0, 0.8, 1.0, 1.0],
          metallic: 0.0,
          roughness: 0.2,
          normalScale: 0.0,
          emissive: [0.0, 0.8, 1.0],
          emissiveIntensity: 2.0,
          specular: 0.5,
          textures: {
            emissive: 'textures/cyan_glow_emissive.png',
            noise: 'textures/noise.png'
          }
        }
      },
      studioMetal: {
        name: 'Studio Metal',
        type: 'pbr',
        properties: {
          baseColor: [0.8, 0.8, 0.8, 1.0],
          metallic: 0.8,
          roughness: 0.2,
          normalScale: 0.7,
          emissive: [0.0, 0.0, 0.0],
          specular: 0.8,
          textures: {
            albedo: 'textures/studio_metal_albedo.png',
            normal: 'textures/studio_metal_normal.png',
            metallic: 'textures/studio_metal_metallic.png',
            roughness: 'textures/studio_metal_roughness.png',
            ao: 'textures/studio_metal_ao.png'
          }
        }
      }
    };
    
    // Initialize post-processing effects
    this.postProcessing = {
      bloom: true,
      motionBlur: false,
      chromaticAberration: true,
      filmGrain: false
    };
  }
  
  /**
   * Load a shader
   * @param name Shader name
   * @param vertexSource Vertex shader source
   * @param fragmentSource Fragment shader source
   * @returns WebGL shader
   */
  public loadShader(name: string, vertexSource: string, fragmentSource: string): WebGLShader {
    console.log(`Loading shader: ${name}`);
    
    // Simulate shader compilation
    const shader: WebGLShader = {
      id: Math.random().toString(36).substring(2, 9),
      name,
      vertexSource,
      fragmentSource,
      uniforms: {},
      attributes: {},
      program: null
    };
    
    // Add to active shaders
    this.activeShaders.set(name, shader);
    
    return shader;
  }
  
  /**
   * Unload a shader
   * @param name Shader name
   * @returns Whether the shader was unloaded
   */
  public unloadShader(name: string): boolean {
    console.log(`Unloading shader: ${name}`);
    
    return this.activeShaders.delete(name);
  }
  
  /**
   * Get a shader
   * @param name Shader name
   * @returns WebGL shader
   */
  public getShader(name: string): WebGLShader | undefined {
    return this.activeShaders.get(name);
  }
  
  /**
   * Apply a material to a shader
   * @param shaderName Shader name
   * @param material Material configuration or preset name
   */
  public applyMaterial(shaderName: string, material: MaterialConfig | keyof ShaderSystem['materialPresets']): void {
    // If material is a string, treat it as a preset name
    if (typeof material === 'string') {
      return this.applyMaterialPreset(shaderName, material);
    }
    
    console.log(`Applying material ${material.name} to shader ${shaderName}`);
    
    const shader = this.activeShaders.get(shaderName);
    
    if (!shader) {
      console.error(`Shader ${shaderName} not found`);
      return;
    }
    
    // Simulate applying material to shader
    shader.uniforms = {
      ...shader.uniforms,
      u_baseColor: material.properties.baseColor,
      u_metallic: material.properties.metallic,
      u_roughness: material.properties.roughness,
      u_normalScale: material.properties.normalScale,
      u_emissive: material.properties.emissive,
      u_specular: material.properties.specular
    };
    
    // Add texture uniforms
    if (material.properties.textures) {
      for (const [name, path] of Object.entries(material.properties.textures)) {
        shader.uniforms[`u_${name}Map`] = path;
      }
    }
  }
  
  /**
   * Apply a material preset to a shader
   * @param shaderName Shader name
   * @param presetName Material preset name
   */
  public applyMaterialPreset(shaderName: string, presetName: keyof ShaderSystem['materialPresets']): void {
    console.log(`Applying material preset ${presetName} to shader ${shaderName}`);
    
    const preset = this.materialPresets[presetName];
    
    if (!preset) {
      console.error(`Material preset ${presetName} not found`);
      return;
    }
    
    // Apply the material configuration directly
    const shader = this.activeShaders.get(shaderName);
    
    if (!shader) {
      console.error(`Shader ${shaderName} not found`);
      return;
    }
    
    // Simulate applying material to shader
    shader.uniforms = {
      ...shader.uniforms,
      u_baseColor: preset.properties.baseColor,
      u_metallic: preset.properties.metallic,
      u_roughness: preset.properties.roughness,
      u_normalScale: preset.properties.normalScale,
      u_emissive: preset.properties.emissive,
      u_specular: preset.properties.specular
    };
    
    // Add texture uniforms
    if (preset.properties.textures) {
      for (const [name, path] of Object.entries(preset.properties.textures)) {
        shader.uniforms[`u_${name}Map`] = path;
      }
    }
  }
  
  /**
   * Create a custom material
   * @param name Material name
   * @param type Material type
   * @param properties Material properties
   * @returns Material configuration
   */
  public createCustomMaterial(
    name: string,
    type: 'pbr' | 'emissive' | 'toon' | 'wireframe',
    properties: Partial<MaterialConfig['properties']>
  ): MaterialConfig {
    console.log(`Creating custom material: ${name}`);
    
    // Create material with default properties
    const material: MaterialConfig = {
      name,
      type,
      properties: {
        baseColor: properties.baseColor || [1.0, 1.0, 1.0, 1.0],
        metallic: properties.metallic !== undefined ? properties.metallic : 0.0,
        roughness: properties.roughness !== undefined ? properties.roughness : 0.5,
        normalScale: properties.normalScale !== undefined ? properties.normalScale : 1.0,
        emissive: properties.emissive || [0.0, 0.0, 0.0],
        specular: properties.specular !== undefined ? properties.specular : 0.5,
        textures: properties.textures || {}
      }
    };
    
    return material;
  }
  
  /**
   * Enable a post-processing effect
   * @param effect Effect name
   */
  public enablePostProcessing(effect: keyof ShaderSystem['postProcessing']): void {
    console.log(`Enabling post-processing effect: ${effect}`);
    
    this.postProcessing[effect] = true;
  }
  
  /**
   * Disable a post-processing effect
   * @param effect Effect name
   */
  public disablePostProcessing(effect: keyof ShaderSystem['postProcessing']): void {
    console.log(`Disabling post-processing effect: ${effect}`);
    
    this.postProcessing[effect] = false;
  }
  
  /**
   * Toggle a post-processing effect
   * @param effect Effect name
   * @returns New effect state
   */
  public togglePostProcessing(effect: keyof ShaderSystem['postProcessing']): boolean {
    console.log(`Toggling post-processing effect: ${effect}`);
    
    this.postProcessing[effect] = !this.postProcessing[effect];
    
    return this.postProcessing[effect];
  }
  
  /**
   * Set a post-processing effect state
   * @param effect Effect name
   * @param enabled Whether the effect is enabled
   */
  public setPostProcessing(effect: keyof ShaderSystem['postProcessing'], enabled: boolean): void {
    console.log(`Setting post-processing effect ${effect} to ${enabled ? 'enabled' : 'disabled'}`);
    
    this.postProcessing[effect] = enabled;
  }
  
  /**
   * Get active post-processing effects
   * @returns Active effects
   */
  public getActivePostProcessingEffects(): string[] {
    return Object.entries(this.postProcessing)
      .filter(([_, enabled]) => enabled)
      .map(([name]) => name);
  }
}

/**
 * Create a new shader system
 */
export function createShaderSystem(): ShaderSystem {
  return new ShaderSystem();
}
